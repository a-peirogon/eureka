import React, { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { GraduationCap, Mail, Lock, Eye, EyeOff, ArrowRight } from 'lucide-react'
import { authApi } from '@/lib/api'
import { useAuthStore } from '@/store/authStore'
import toast from 'react-hot-toast'
import { Spinner } from '@/components/ui'

export default function Login() {
  const navigate = useNavigate()
  const setAuth = useAuthStore(s => s.setAuth)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const data = await authApi.login(email, password)
      setAuth(data.user, data.access_token, data.refresh_token)
      toast.success(`¡Bienvenido, ${data.user.full_name.split(' ')[0]}!`)
      navigate('/dashboard')
    } catch (err: any) {
      const msg = err?.response?.data?.detail || 'Credenciales incorrectas'
      setError(msg)
    } finally {
      setLoading(false)
    }
  }

  const demoLogin = (role: 'admin' | 'docente' | 'estudiante') => {
    const creds = {
      admin:      { email: 'admin@eureka.edu.co',      password: 'Admin123!' },
      docente:    { email: 'docente@eureka.edu.co',    password: 'Admin123!' },
      estudiante: { email: 'estudiante@eureka.edu.co', password: 'Admin123!' },
    }
    setEmail(creds[role].email)
    setPassword(creds[role].password)
  }

  return (
    <div className="min-h-screen flex">
      <div className="hidden lg:flex lg:w-1/2 bg-navy-900 flex-col justify-between p-12 relative overflow-hidden">
        <div className="absolute -top-20 -left-20 w-80 h-80 bg-primary-700/30 rounded-full blur-3xl" />
        <div className="absolute -bottom-20 -right-20 w-96 h-96 bg-gold-500/10 rounded-full blur-3xl" />
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-12">
            <div className="w-10 h-10 rounded-xl bg-primary-500 flex items-center justify-center">
              <GraduationCap size={22} className="text-white" />
            </div>
            <span className="font-display text-2xl text-white">Eureka ICFES</span>
          </div>
          <h2 className="font-display text-4xl text-white leading-tight mb-4">
            Prepárate para el<br />
            <span className="text-primary-400">ICFES Saber 11</span>
          </h2>
          <p className="text-white/60 text-lg leading-relaxed">
            Plataforma de simulacros inteligentes con analítica académica y generación de preguntas con IA para instituciones colombianas.
          </p>
        </div>
        <div className="relative z-10 grid grid-cols-3 gap-4">
          {[{ n: '5', label: 'Áreas ICFES' }, { n: 'IA', label: 'Generación' }, { n: '100%', label: 'Online' }].map(s => (
            <div key={s.n} className="bg-white/10 rounded-2xl p-4 text-center">
              <p className="font-display text-2xl text-white">{s.n}</p>
              <p className="text-xs text-white/50 mt-1">{s.label}</p>
            </div>
          ))}
        </div>
      </div>
      <div className="flex-1 flex flex-col items-center justify-center p-8 bg-white">
        <div className="w-full max-w-md">
          <div className="flex items-center gap-3 mb-8 lg:hidden">
            <div className="w-10 h-10 rounded-xl bg-primary-500 flex items-center justify-center">
              <GraduationCap size={22} className="text-white" />
            </div>
            <span className="font-display text-2xl text-navy-900">Eureka ICFES</span>
          </div>
          <h1 className="font-display text-3xl text-navy-900 mb-2">Iniciar sesión</h1>
          <p className="text-slate-500 mb-8">Ingresa a tu cuenta para continuar</p>
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm mb-6">{error}</div>
          )}
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="label">Correo electrónico</label>
              <div className="relative">
                <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="input pl-10" placeholder="correo@institución.edu.co" required />
              </div>
            </div>
            <div>
              <label className="label">Contraseña</label>
              <div className="relative">
                <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input type={showPass ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} className="input pl-10 pr-10" placeholder="••••••••" required />
                <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                  {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
            <button type="submit" disabled={loading} className="btn-primary w-full justify-center py-3">
              {loading ? <Spinner size="sm" /> : <ArrowRight size={16} />}
              {loading ? 'Ingresando...' : 'Ingresar'}
            </button>
          </form>
          <div className="mt-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="flex-1 h-px bg-slate-200" />
              <span className="text-xs text-slate-400 font-medium">Cuentas demo</span>
              <div className="flex-1 h-px bg-slate-200" />
            </div>
            <div className="grid grid-cols-3 gap-2">
              {(['estudiante', 'docente', 'admin'] as const).map(role => (
                <button key={role} onClick={() => demoLogin(role)}
                  className="px-3 py-2 text-xs font-medium rounded-xl border border-slate-200 text-slate-600 hover:border-primary-300 hover:text-primary-600 transition-all capitalize">
                  {role}
                </button>
              ))}
            </div>
            <p className="text-xs text-slate-400 mt-2 text-center">Clic para prellenar credenciales demo</p>
          </div>
        </div>
      </div>
    </div>
  )
}
